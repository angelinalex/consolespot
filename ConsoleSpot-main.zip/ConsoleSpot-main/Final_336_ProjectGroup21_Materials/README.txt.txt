admin credentials -> username = admin, password = adminpw

customer representative is showcased in the video, and admin can create more

users can create their own accounts


Decided to go for a more simplistic UI, and the video showcases some of the best features we have.
Most of the steps have been completed!

Demo Video is on youtube (NO audio or audio) ! 
link: https://www.youtube.com/watch?v=eAtak0sPT6U
Demo Video is also attached
