# cs336group21final
updated format for final

(old setup instructions)

1. zip file -> extract and drag into new (existing?) workspace
2. sql files -> open in a connected mySQL workbench
3. Available inputs

5/3
1. Import war file into project
2. Replace old sql file with new
3. Look over all tables in new sql file and replace them with old attributes in sql table editor "alter table"

(final project showcase)
https://www.youtube.com/watch?v=JEsMkUhlOWo
